# Employee Management System (Servlet + JSP + Hibernate + MySQL)

A minimal CRUD web app: Add, list, and delete employees. Built with **Jakarta Servlet 5**, **Hibernate 6**, **MySQL**, packaged as a **WAR** for Tomcat 10+.

## Prerequisites
- Java 17
- Maven 3.8+
- MySQL 8.x
- Tomcat 10.1+ (Jakarta namespace)
- IntelliJ IDEA (Community or Ultimate)

## Setup (IntelliJ IDEA)
1. **Clone / Open**
   - `File > New > Project from Existing Sources...` and select this folder.
   - IntelliJ will detect Maven and import dependencies.
2. **Database**
   - Create database: `CREATE DATABASE ems;`
   - Update credentials in `src/main/resources/hibernate.cfg.xml` (username/password).
3. **Build**
   - Run `mvn clean package` (or use IntelliJ Maven tool window).
   - This generates `target/EmployeeManagementSystem.war`.
4. **Deploy on Tomcat 10.1+**
   - Copy the WAR to Tomcat's `webapps/` folder **or** configure Tomcat run configuration in IntelliJ.
   - Open `http://localhost:8080/EmployeeManagementSystem/`.
5. **Pages**
   - Home: `/index.jsp`
   - Add Employee: `/addEmployee.jsp`
   - List Employees: `/listEmployee`

## Notes
- Default DB URL in `hibernate.cfg.xml` is `jdbc:mysql://localhost:3306/ems` with user `root` / `root`. Change as needed.
- `hibernate.hbm2ddl.auto=update` for quick start. For production, consider `validate` or explicit migrations.
- This is a starter. You can add update/edit, authentication, and department modules.

## License
MIT
