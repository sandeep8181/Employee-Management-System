package com.ems.dao;

import com.ems.model.Employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.List;

public class EmployeeDAO {
    private static final SessionFactory factory = new Configuration()
            .configure("hibernate.cfg.xml")
            .buildSessionFactory();

    public void addEmployee(Employee emp) {
        try (Session session = factory.openSession()) {
            Transaction tx = session.beginTransaction();
            session.persist(emp);
            tx.commit();
        }
    }

    public List<Employee> getAllEmployees() {
        try (Session session = factory.openSession()) {
            return session.createQuery("from Employee", Employee.class).list();
        }
    }

    public void deleteEmployee(int id) {
        try (Session session = factory.openSession()) {
            Transaction tx = session.beginTransaction();
            Employee emp = session.get(Employee.class, id);
            if (emp != null) session.remove(emp);
            tx.commit();
        }
    }
}
